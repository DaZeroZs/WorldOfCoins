'use strict';

// Instructor / demo solver.
// Run while the server is running:
//   npm run solve
// or:
//   node solve.js

const crypto = require('crypto');
const { ec: EC } = require('elliptic');

const ec = new EC('secp256k1');
const n = BigInt('0x' + ec.curve.n.toString(16));
const BASE_URL = process.env.BASE_URL || 'http://127.0.0.1:3000';

function mod(a, m = n) {
  const r = a % m;
  return r >= 0n ? r : r + m;
}

function egcd(a, b) {
  let oldR = a, r = b;
  let oldS = 1n, s = 0n;
  while (r !== 0n) {
    const q = oldR / r;
    [oldR, r] = [r, oldR - q * r];
    [oldS, s] = [s, oldS - q * s];
  }
  return [oldR, oldS];
}

function invMod(a, m = n) {
  const [g, x] = egcd(mod(a, m), m);
  if (g !== 1n) throw new Error('No modular inverse');
  return mod(x, m);
}

function to64Hex(x) {
  return mod(x).toString(16).padStart(64, '0');
}

function sha256Hex(message) {
  return crypto.createHash('sha256').update(message, 'utf8').digest('hex');
}

function zFromMessage(message) {
  return BigInt('0x' + sha256Hex(message)) % n;
}

function pointXFromK(k) {
  const P = ec.g.mul(k.toString(16));
  return BigInt('0x' + P.getX().toString(16));
}

function signWithPrivateKey(message, d) {
  // Use a fresh demo nonce for the forged admin signature.
  // In real systems this should be generated deterministically via RFC 6979 or securely random.
  const k = 0x123456789abcdef123456789abcdef123456789abcdef123456789abcdef1234n % n;
  const z = zFromMessage(message);
  const r = mod(pointXFromK(k));
  const s = mod(invMod(k) * (z + r * d));
  return { r: to64Hex(r), s: to64Hex(s) };
}

async function main() {
  const challenge = await fetch(`${BASE_URL}/start`).then(r => r.json());

  const sig1 = challenge.signature1;
  const sig2 = challenge.signature2;

  const r = BigInt('0x' + sig1.r);
  const s1 = BigInt('0x' + sig1.s);
  const s2 = BigInt('0x' + sig2.s);
  const z1 = BigInt('0x' + sig1.z);
  const z2 = BigInt('0x' + sig2.z);

  if (sig1.r !== sig2.r) {
    throw new Error('r values differ; this is not the intended nonce-reuse challenge.');
  }

  // ECDSA:
  // s1 = k^-1 * (z1 + r*d) mod n
  // s2 = k^-1 * (z2 + r*d) mod n
  // k  = (z1 - z2) * (s1 - s2)^-1 mod n
  // d  = (s1*k - z1) * r^-1 mod n
  const recoveredK = mod((z1 - z2) * invMod(s1 - s2));
  const recoveredD = mod((s1 * recoveredK - z1) * invMod(r));

  console.log('[+] r1 == r2, so nonce k was reused.');
  console.log('[+] recovered k =', to64Hex(recoveredK));
  console.log('[+] recovered private key d =', to64Hex(recoveredD));

  const adminMessage = challenge.adminMessageToSign;
  const forged = signWithPrivateKey(adminMessage, recoveredD);

  console.log('[+] forged admin signature:');
  console.log('    message =', adminMessage);
  console.log('    r       =', forged.r);
  console.log('    s       =', forged.s);

  const url = `${BASE_URL}/claim?message=${encodeURIComponent(adminMessage)}&r=${forged.r}&s=${forged.s}`;
  console.log('[+] claim URL:');
  console.log(url);

  const result = await fetch(url).then(r => r.json());
  console.log('[+] server response:');
  console.log(result);
}

main().catch(err => {
  console.error('[-]', err);
  process.exit(1);
});
