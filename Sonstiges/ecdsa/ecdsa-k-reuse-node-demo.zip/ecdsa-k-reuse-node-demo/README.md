# ECDSA k-Reuse CTF Demo

Diese Demo zeigt, warum man bei ECDSA die Nonce `k` niemals zweimal verwenden darf.

Der Server ist absichtlich verwundbar: Er signiert zwei verschiedene Nachrichten mit demselben privaten Schlüssel `d` und derselben Nonce `k` auf `secp256k1`.

## Start

```cmd
npm install
npm start
```

Dann öffnen:

```text
http://127.0.0.1:3000/start
```

## Ziel für Studenten

Der Endpoint `/start` gibt zwei Signaturen aus:

```text
message1, z1, r1, s1
message2, z2, r2, s2
```

Auffällig ist:

```text
r1 == r2
```

Das ist bei ECDSA ein starkes Indiz, dass dieselbe Nonce `k` wiederverwendet wurde.

Die Studenten sollen daraus den privaten Schlüssel `d` berechnen und danach die Admin-Nachricht signieren:

```text
role=admin&action=get_flag
```

Dann die Signatur an `/claim` senden:

```text
http://127.0.0.1:3000/claim?message=role%3Dadmin%26action%3Dget_flag&r=<r_hex>&s=<s_hex>
```

## Mathematische Lösung

ECDSA-Signatur:

```text
r = (k * G).x mod n
s = k^-1 * (z + r*d) mod n
```

Für zwei Signaturen mit demselben `k` und gleichem `r` gilt:

```text
s1 = k^-1 * (z1 + r*d) mod n
s2 = k^-1 * (z2 + r*d) mod n
```

Subtrahieren:

```text
s1 - s2 = k^-1 * (z1 - z2) mod n
```

Daraus:

```text
k = (z1 - z2) * (s1 - s2)^-1 mod n
```

Und danach:

```text
d = (s1*k - z1) * r^-1 mod n
```

## Instructor-Lösung

Server in einem Terminal starten:

```cmd
npm start
```

In einem zweiten Terminal:

```cmd
npm run solve
```

Das Solver-Skript ruft `/start` ab, berechnet `k`, rekonstruiert den privaten Schlüssel `d`, signiert die Admin-Nachricht und ruft `/claim` auf.

Erwartete Flag:

```text
FLAG{never_reuse_ecdsa_nonce_k}
```

## Didaktischer Fokus

Diese Demo zeigt nicht, dass ECDSA selbst kaputt ist. Sie zeigt falsche Verwendung:

```text
Falsch: gleiche Nonce k mehrfach verwenden
Richtig: pro Signatur eine neue sichere Nonce oder RFC-6979 deterministic nonce
```

Bei Bitcoin/Ethereum wäre eine wiederverwendete ECDSA-Nonce katastrophal, weil aus zwei Signaturen der private Schlüssel berechnet werden kann.
